//
//  ShuftiPro.h
//  ShuftiPro
//
//  Created by Zubair Ismail on 18/08/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for ShuftiPro.
FOUNDATION_EXPORT double ShuftiProVersionNumber;

//! Project version string for ShuftiPro.
FOUNDATION_EXPORT const unsigned char ShuftiProVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ShuftiPro/PublicHeader.h>


